//: generics/coffee/Americano.java
package generics.coffee;
public class Americano extends Coffee {} ///:~
