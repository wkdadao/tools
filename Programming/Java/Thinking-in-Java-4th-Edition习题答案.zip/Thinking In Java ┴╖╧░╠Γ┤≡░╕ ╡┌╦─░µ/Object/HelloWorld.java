// TIJ4 Chapter Object, Exericise 2, page 89
// object/HelloWorld.java
// Following the HelloDate.java example in this chapter, create a "hello, world" 
// program that simply displays that statement.

public class HelloWorld {
	public static void main(String[] args) {		
		System.out.println("Hello World!");
	}
}